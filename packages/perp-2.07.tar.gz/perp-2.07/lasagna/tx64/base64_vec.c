/* base64_vec.c
** standard base64 encoding vector
** provided for tx64 module
** wcm, 2009.07.20 - 2009.07.20
*/
const char base64_vec[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                          "abcdefghijklmnopqrstuvwxyz"
                          "0123456789"
                          "+/"
                          "=";

/* eof: base64_vec.c */
